import React from 'react';

// Definición simple del tipo de tema para las props
interface Theme {
  startBg: string;
  startHover: string;
  startText: string;
  accentRing: string;
  pauseBg: string;
  pauseHover: string;
  pauseText: string;
  resetBg: string;
  resetHover: string;
  resetText: string;
}

interface ControlsProps {
  isRunning: boolean;
  hasStarted: boolean;
  onStart: () => void;
  onPause: () => void;
  onReset: () => void;
  startLabel: string;
  pauseLabel: string;
  resetLabel: string;
  theme: Theme;
  onInteraction: () => void;
}

const Controls: React.FC<ControlsProps> = ({ 
  isRunning, 
  hasStarted, 
  onStart, 
  onPause, 
  onReset, 
  startLabel, 
  pauseLabel, 
  resetLabel,
  theme,
  onInteraction
}) => {

  const handleStart = () => {
    onInteraction();
    onStart();
  };

  const handlePause = () => {
    onInteraction();
    onPause();
  };

  const handleReset = () => {
    onInteraction();
    onReset();
  };

  return (
    <div className="flex items-center justify-center gap-4 w-full">
      <button
        onClick={handleReset}
        disabled={!hasStarted}
        className={`px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed ${theme.resetBg} ${theme.resetText} ${theme.resetHover}`}
        aria-label={resetLabel}
      >
        {resetLabel}
      </button>
      {isRunning ? (
        <button
          onClick={handlePause}
          className={`px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 w-40 ${theme.pauseBg} ${theme.pauseText} ${theme.pauseHover} ${theme.accentRing}`}
          aria-label={pauseLabel}
        >
          {pauseLabel}
        </button>
      ) : (
        <button
          onClick={handleStart}
          className={`px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 w-40 ${theme.startBg} ${theme.startText} ${theme.startHover} ${theme.accentRing}`}
          aria-label={startLabel}
        >
          {startLabel}
        </button>
      )}
    </div>
  );
};

export default Controls;