import React from 'react';

// Definición simple del tipo de tema para las props
interface Theme {
  displayBg: string;
  displayTextColor: string;
}

interface StopwatchDisplayProps {
  time: number;
  theme: Theme;
  fontClass: string;
}

const StopwatchDisplay: React.FC<StopwatchDisplayProps> = ({ time, theme, fontClass }) => {
  const formatTime = (timeInMillis: number): string => {
    const minutes = Math.floor((timeInMillis / 60000) % 60).toString().padStart(2, '0');
    const seconds = Math.floor((timeInMillis / 1000) % 60).toString().padStart(2, '0');
    const centiseconds = Math.floor((timeInMillis / 10) % 100).toString().padStart(2, '0');
    
    return `${minutes}:${seconds}.${centiseconds}`;
  };

  return (
    <div className={`text-8xl md:text-9xl tracking-wider w-full text-center py-4 rounded-lg shadow-inner ${theme.displayBg} ${theme.displayTextColor} ${fontClass}`}>
      {formatTime(time)}
    </div>
  );
};

export default StopwatchDisplay;