import { useState, useEffect, useCallback } from 'react';

export const useTextToSpeech = (langCode: string, theme: string) => {
  const [voice, setVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    if ('speechSynthesis' in window) {
      setIsSupported(true);
    } else {
      console.warn('La API de Síntesis de Voz no es soportada en este navegador.');
      return;
    }

    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      if (availableVoices.length === 0) {
        return;
      }

      // Prioridad 1: Buscar una voz que coincida exactamente con el código de idioma y región (ej. 'de-CH').
      const specificVoices = availableVoices.filter(
        (v) => v.lang === langCode
      );

      if (specificVoices.length > 0) {
        setVoice(specificVoices[specificVoices.length - 1]);
        return; // ¡Voz específica encontrada! No seguir buscando.
      }

      // Prioridad 2: Si no se encuentra, buscar una voz que coincida con el idioma base (ej. 'de').
      const fallbackVoices = availableVoices.filter((v) =>
        v.lang.startsWith(langCode.split('-')[0])
      );
      
      if (fallbackVoices.length > 0) {
        // Usar la última de la lista como fallback para intentar obtener una variante.
        setVoice(fallbackVoices[fallbackVoices.length - 1]);
      } else {
        // No se encontró ninguna voz para este idioma.
        setVoice(null);
      }
    };

    loadVoices();
    window.speechSynthesis.addEventListener('voiceschanged', loadVoices);
    
    return () => {
        window.speechSynthesis.removeEventListener('voiceschanged', loadVoices);
    };

  }, [langCode]);

  const speak = useCallback((text: string) => {
    if (!isSupported || !voice || !text) return;

    // Cancelar cualquier locución anterior para evitar que se pongan en cola los números
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = voice;
    utterance.lang = voice.lang;
    
    if (theme === 'metal_gear') {
        utterance.pitch = 0.5; // Tono más grave para simular a Snake
        utterance.rate = 1.0; // Ligeramente más lento
    } else {
        utterance.pitch = 1;
        utterance.rate = 1.1; // Ligeramente más rápido para contar
    }
    
    utterance.volume = 1;

    window.speechSynthesis.speak(utterance);
  }, [voice, isSupported, theme]);

  const cancelSpeech = useCallback(() => {
    if(isSupported) {
        window.speechSynthesis.cancel();
    }
  }, [isSupported]);

  return { speak, cancelSpeech, isReady: !!voice };
};