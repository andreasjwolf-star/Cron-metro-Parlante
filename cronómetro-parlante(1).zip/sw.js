const STATIC_CACHE_NAME = 'cronometro-parlante-static-v1';
const DYNAMIC_CACHE_NAME = 'cronometro-parlante-dynamic-v1';

// Recursos del App Shell que se cachearán durante la instalación.
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/index.tsx',
  '/App.tsx',
  '/components/Controls.tsx',
  '/components/StopwatchDisplay.tsx',
  '/hooks/useStopwatch.ts',
  '/hooks/useTextToSpeech.ts',
  '/manifest.json'
];

// Evento de instalación: se cachean los recursos estáticos.
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(STATIC_CACHE_NAME).then(cache => {
      console.log('Precaching App Shell');
      return cache.addAll(STATIC_ASSETS);
    })
  );
});

// Evento de activación: se eliminan las cachés antiguas.
self.addEventListener('activate', event => {
  const cacheWhitelist = [STATIC_CACHE_NAME, DYNAMIC_CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Eliminando caché antigua:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  return self.clients.claim();
});

// Evento de fetch: se interceptan las peticiones de red.
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);

  // Estrategia "Cache first" para los recursos locales (App Shell)
  if (STATIC_ASSETS.some(asset => url.pathname.endsWith(asset.substring(1)))) {
    event.respondWith(
      caches.match(request).then(cachedResponse => {
        return cachedResponse || fetch(request);
      })
    );
    return;
  }
  
  // Estrategia "Network falling back to cache" para recursos dinámicos o externos
  event.respondWith(
    caches.open(DYNAMIC_CACHE_NAME).then(cache => {
      return fetch(request).then(networkResponse => {
        // Si la petición a la red tiene éxito, la cacheamos y la devolvemos
        cache.put(request, networkResponse.clone());
        return networkResponse;
      }).catch(() => {
        // Si la red falla, intentamos servir desde la caché
        return cache.match(request);
      });
    })
  );
});
